#!/bin/sh

qemu-system-x86_64 \
    -kernel ./bzImage \
    -initrd ./initramfs.cpio.gz \
    -cpu qemu64,+smap,+smep \
    -smp 1 \
    -m 500M \
    -append "console=ttyS0 quiet loglevel=3 oops=panic panic_on_warn=1 panic=-1" \
    -monitor /dev/null \
    -nographic \
    -no-reboot \
    -drive file=flag.txt,format=raw,media=disk,if=virtio,readonly=on 