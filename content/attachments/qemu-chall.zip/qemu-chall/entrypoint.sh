#!/bin/bash
echo "[+] Waiting for connections"
socat tcp-l:1337,reuseaddr,fork EXEC:"/opt/run.sh",pty,stderr
echo "[+] Exiting"
