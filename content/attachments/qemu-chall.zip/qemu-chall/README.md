## Description
Did you know that iret can be executed in ring 3?
nc chall.kqx.io 1337

## Note
Be sure to be using the same version of QEMU as the one in the container!
If you are stuck but made some progress just contact us (contact info [here](https://kqx.io/about/))
